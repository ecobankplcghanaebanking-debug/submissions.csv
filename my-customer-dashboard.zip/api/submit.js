import { Octokit } from "octokit";

export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  const { fullname, email, update } = req.body;

  const octokit = new Octokit({
    auth: process.env.GITHUB_TOKEN, // Add this in hosting settings
  });

  const repoOwner = "YOUR_GITHUB_USERNAME"; // 👈 replace with your GitHub username
  const repoName = "my-customer-dashboard"; // 👈 replace with your repo name
  const filePath = "submissions.csv";

  try {
    // Fetch current CSV
    let { data: fileData } = await octokit.repos.getContent({
      owner: repoOwner,
      repo: repoName,
      path: filePath,
    });

    let content = Buffer.from(fileData.content, "base64").toString("utf-8");

    // Add new row
    const newLine = `"${fullname}","${email}","${update}"\n`;
    content += newLine;

    // Push back to GitHub
    await octokit.repos.createOrUpdateFileContents({
      owner: repoOwner,
      repo: repoName,
      path: filePath,
      message: `New submission from ${fullname}`,
      content: Buffer.from(content).toString("base64"),
      sha: fileData.sha,
    });

    res.status(200).json({ success: true, message: "Submission saved!" });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Failed to save submission" });
  }
}